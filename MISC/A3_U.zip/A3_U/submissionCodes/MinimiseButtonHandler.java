
public interface MinimiseButtonHandler {
	public void OnClickMinimiseButton(Widget w, EventArgs e);

}
